from django.apps import AppConfig


class EsusuConfig(AppConfig):
    name = 'esusu'
